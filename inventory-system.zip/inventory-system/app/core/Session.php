<?php
namespace App\Core;

/**
 * Session management with security best practices
 * Following Lecture 10 security principles
 */
class Session
{
    /**
     * Start secure session
     */
    public static function start()
    {
        if (session_status() === PHP_SESSION_NONE) {
            // Session cookie parameters for security
            session_set_cookie_params([
                'lifetime' => 86400, // 24 hours
                'path' => '/',
                'domain' => $_SERVER['HTTP_HOST'] ?? 'localhost',
                'secure' => isset($_SERVER['HTTPS']), // Only over HTTPS if available
                'httponly' => true, // Prevent JavaScript access
                'samesite' => 'Lax' // CSRF protection
            ]);
            
            session_start();

            // ========== ADD THESE 4 LINES ==========
            // Session timeout check (30 minutes)
            $timeout = 1800; // 30 minutes in seconds
            
        if (isset($_SESSION['LAST_ACTIVITY']) && 
            (time() - $_SESSION['LAST_ACTIVITY'] > $timeout)) {
            // Session expired - destroy and restart
            self::destroy();
            session_start();
        }
        
        // Update last activity timestamp
        $_SESSION['LAST_ACTIVITY'] = time();
        // ========== END OF ADDED CODE ==========

            // Regenerate session ID periodically to prevent fixation
            if (!isset($_SESSION['last_regeneration'])) {
                self::regenerate();
            } elseif (time() - $_SESSION['last_regeneration'] > 1800) { // 30 minutes
                self::regenerate();
            }
        }
    }
    
    /**
     * Regenerate session ID (security against session fixation)
     */
    public static function regenerate()
    {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
    
    /**
     * Set session variable
     */
    public static function set($key, $value)
    {
        $_SESSION[$key] = $value;
    }
    
    /**
     * Get session variable
     */
    public static function get($key, $default = null)
    {
        return $_SESSION[$key] ?? $default;
    }
    
    /**
     * Check if session variable exists
     */
    public static function has($key)
    {
        return isset($_SESSION[$key]);
    }
    
    /**
     * Remove session variable
     */
    public static function remove($key)
    {
        unset($_SESSION[$key]);
    }
    
    /**
     * Destroy entire session (logout)
     */
    public static function destroy()
    {
        // Clear session data
        $_SESSION = [];
        
        // Delete session cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }
        
        // Destroy session
        session_destroy();
    }
    
    /**
     * Set flash message (temporary message for one request)
     */
    public static function flash($key, $message)
    {
        $_SESSION['flash'][$key] = $message;
    }
    
    /**
     * Get and clear flash message
     */
    public static function getFlash($key)
    {
        $message = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $message;
    }
    
    /**
     * Check if user is logged in
     */
    public static function isLoggedIn()
    {
        return self::has('user_id') && self::has('user_role');
    }
    
    /**
     * Check if user has specific role
     */
    public static function hasRole($role)
    {
        return self::get('user_role') === $role;
    }
    
    /**
     * Require authentication - redirect to login if not logged in
     */
    public static function requireAuth()
    {
        if (!self::isLoggedIn()) {
            self::flash('error', 'Please login to access this page.');
            header('Location: index.php?page=login');
            exit;
        }
    }
    
    /**
     * Require specific role - redirect if not authorized
     */
    public static function requireRole($role)
    {
        self::requireAuth();
        
        if (!self::hasRole($role)) {
            self::flash('error', 'You do not have permission to access this page.');
            header('Location: index.php?page=dashboard');
            exit;
        }
    }
}