<?php
namespace App\Core;

use PDO;
use PDOException;

/**
 * Database connection class using PDO with prepared statements
 * Follows security practices from Lecture 10
 */
class Database
{
    private static $instance = null;
    private $connection;
    
    // Database configuration - UPDATE THESE FOR YOUR SYSTEM
    private $host = 'localhost';
    private $dbname = 'np03cs4a240250';
    private $username = 'np03cs4a240250';      // Default XAMPP username
    private $password = 'UjnfmYHris';          // Default XAMPP password (empty)
    private $charset = 'utf8mb4';
    
    /**
     * Private constructor - prevents direct creation
     */
    private function __construct()
    {
        try {
            // DSN (Data Source Name)
            $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset={$this->charset}";
            
            // PDO options
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Throw exceptions on errors
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Return associative arrays
                PDO::ATTR_EMULATE_PREPARES   => false,                  // Use real prepared statements
            ];
            
            // Create PDO instance
            $this->connection = new PDO($dsn, $this->username, $this->password, $options);
            
            // echo "Database connected successfully!<br>"; // Remove this after testing
            
        } catch (PDOException $e) {
            // Log error and show user-friendly message
            error_log("Database Connection Error: " . $e->getMessage());
            die("Could not connect to the database. Please try again later.");
        }
    }
    
    /**
     * Get database instance (Singleton pattern)
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Get the PDO connection
     */
    public function getConnection()
    {
        return $this->connection;
    }
    
    /**
     * Prepare a statement (security: always use prepared statements)
     */
    public function prepare($sql)
    {
        return $this->connection->prepare($sql);
    }
    
    /**
     * Execute a query with parameters (for INSERT, UPDATE, DELETE)
     */
    public function executeQuery($sql, $params = [])
    {
        try {
            $stmt = $this->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log("Query Error: " . $e->getMessage() . " SQL: " . $sql);
            throw new \Exception("Database error occurred.");
        }
    }
    
    /**
     * Fetch all rows
     */
    public function fetchAll($sql, $params = [])
    {
        $stmt = $this->executeQuery($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Fetch a single row
     */
    public function fetchOne($sql, $params = [])
    {
        $stmt = $this->executeQuery($sql, $params);
        return $stmt->fetch();
    }
    
    /**
     * Get last inserted ID
     */
    public function lastInsertId()
    {
        return $this->connection->lastInsertId();
    }
    
    /**
     * Begin transaction
     */
    public function beginTransaction()
    {
        return $this->connection->beginTransaction();
    }
    
    /**
     * Commit transaction
     */
    public function commit()
    {
        return $this->connection->commit();
    }
    
    /**
     * Rollback transaction
     */
    public function rollback()
    {
        return $this->connection->rollBack();
    }
    
    /**
     * Prevent cloning
     */
    private function __clone() {}
    
    /**
     * Prevent unserialization
     */
    public function __wakeup() {}
}