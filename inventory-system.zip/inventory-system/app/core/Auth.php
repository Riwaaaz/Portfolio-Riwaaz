<?php
namespace App\Core;

use App\Core\Database;
use PDOException;

/**
 * Authentication system with password hashing and verification
 */
class Auth
{
    private $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * Login user with email/username and password
     * Returns user array on success, false on failure
     */
    public function login($identifier, $password)
    {
        try {
            // Check if identifier is email or username
            $isEmail = filter_var($identifier, FILTER_VALIDATE_EMAIL);
            $field = $isEmail ? 'email' : 'username';
            
            // Use prepared statement to prevent SQL injection
            $sql = "SELECT id, username, email, password, role FROM users WHERE $field = ? LIMIT 1";
            $user = $this->db->fetchOne($sql, [$identifier]);
            
            // Verify user exists and password is correct
            if ($user && password_verify($password, $user['password'])) {
                // Start secure session
                Session::start();
                Session::regenerate(); // Prevent session fixation
                
                // Store user info in session (NOT password!)
                Session::set('user_id', $user['id']);
                Session::set('user_username', $user['username']);
                Session::set('user_email', $user['email']);
                Session::set('user_role', $user['role']);
                Session::set('logged_in', true);
                
                // Update last login timestamp (optional)
                $this->updateLastLogin($user['id']);
                
                return $user;
            }
            
            return false;
            
        } catch (PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Register new user (if we need registration later)
     */
    public function register($username, $email, $password, $role = 'user')
    {
        try {
            // Hash password before storing
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user with prepared statement
            $sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
            $this->db->executeQuery($sql, [$username, $email, $hashedPassword, $role]);
            
            return $this->db->lastInsertId();
            
        } catch (PDOException $e) {
            // Check for duplicate entry
            if ($e->getCode() == 23000) { // MySQL duplicate entry
                return false;
            }
            error_log("Registration error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Logout user
     */
    public function logout()
    {
        Session::destroy();
        return true;
    }
    
    /**
     * Get current logged in user
     */
    public function user()
    {
        if (Session::isLoggedIn()) {
            return [
                'id' => Session::get('user_id'),
                'username' => Session::get('user_username'),
                'email' => Session::get('user_email'),
                'role' => Session::get('user_role')
            ];
        }
        
        return null;
    }
    
    /**
     * Update last login timestamp
     */
    private function updateLastLogin($userId)
    {
        try {
            $sql = "UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?";
            $this->db->executeQuery($sql, [$userId]);
        } catch (PDOException $e) {
            error_log("Update last login error: " . $e->getMessage());
        }
    }
    
    /**
     * Validate password strength
     */
    public static function validatePassword($password)
    {
        $errors = [];
        
        if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters long.";
        }
        
        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = "Password must contain at least one uppercase letter.";
        }
        
        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = "Password must contain at least one lowercase letter.";
        }
        
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one number.";
        }
        
        return $errors;
    }
}