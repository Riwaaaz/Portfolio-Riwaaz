@extends('layouts.master')

@section('title', 'Login - Inventory System')

@section('main-class', 'container')

@section('content')
<div class="login-container">
    <div class="card login-card">
        <div class="card-header login-header text-center">
            <h4 class="mb-0"><i class="bi bi-box-seam"></i> Inventory System Login</h4>
        </div>
        <div class="card-body p-4">
            @if($error = \App\Core\Session::getFlash('error'))
            <div class="alert alert-danger">
                {{ $error }}
            </div>
            @endif
            
            <form method="POST" action="login.php" id="loginForm">
                <!-- CSRF Token -->
                <input type="hidden" name="csrf_token" value="{{ $csrf_token }}">
                
                <div class="mb-3">
                    <label for="username" class="form-label">
                        <i class="bi bi-person"></i> Username or Email
                    </label>
                    <input type="text" 
                           class="form-control" 
                           id="username" 
                           name="username" 
                           required
                           autofocus
                           placeholder="Enter username or email">
                    <div class="form-text">Use 'admin' for demo</div>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">
                        <i class="bi bi-lock"></i> Password
                    </label>
                    <input type="password" 
                           class="form-control" 
                           id="password" 
                           name="password" 
                           required
                           placeholder="Enter password">
                    <div class="form-text">Use 'admin123' for demo</div>
                </div>
                
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="remember" name="remember">
                    <label class="form-check-label" for="remember">Remember me</label>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="bi bi-box-arrow-in-right"></i> Login
                    </button>
                </div>
            </form>
            
            <div class="mt-3 text-center">
                <small class="text-muted">
                    Demo Credentials: admin / admin123
                </small>
            </div>
        </div>

    </div>
    <div class="text-center mt-4">
        <a href="index.php?page=home" class="btn btn-outline-success">
            <i class="bi bi-house-door"></i> Return to Homepage
        </a>
    </div>
    <div class="text-center mt-3">
        <small class="text-muted">
            &copy; {{ date('Y') }} Inventory System - For Educational Purposes
        </small>
    </div>
</div>
@endsection

@section('scripts')
<script>
document.getElementById('loginForm').addEventListener('submit', function(e) {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    
    if (!username || !password) {
        e.preventDefault();
        alert('Please fill in all fields.');
    }
});
</script>
@endsection

<?php
// Tell master layout to hide navbar on login page
$hideNavbar = true;
?>