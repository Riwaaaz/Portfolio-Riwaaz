@extends('layouts.master')

@section('title', 'Manage Users - Inventory System')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="bi bi-people"></i> Manage Users</h1>
    <a href="index.php?page=dashboard" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Back to Dashboard
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">System Users</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Joined</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($users as $user)
                    <tr>
                        <td>{{ $user['id'] }}</td>
                        <td>
                            <strong>{{ $user['username'] }}</strong>
                            @if($user['role'] == 'admin')
                            <span class="badge bg-success ms-2">Admin</span>
                            @endif
                        </td>
                        <td>{{ $user['email'] }}</td>
                        <td>
                            <span class="badge bg-{{ $user['role'] == 'admin' ? 'success' : 'info' }}">
                                {{ ucfirst($user['role']) }}
                            </span>
                        </td>
                        <td>{{ date('M d, Y', strtotime($user['created_at'])) }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        
        <div class="alert alert-info mt-3">
            <i class="bi bi-info-circle"></i>
            <strong>Note:</strong> User management is a basic view-only feature. 
            Full user management (add/edit/delete) can be implemented as an extension.
        </div>
    </div>
</div>
@endsection