@extends('layouts.master')

@section('title', 'Add Product - Inventory System')

@section('styles')
<style>
    .form-section {
        background: #f8f9fa;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        border-left: 4px solid var(--primary-green);
    }
    
    .form-section h5 {
        color: var(--text-dark);
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #dee2e6;
    }
    
    .required::after {
        content: " *";
        color: #dc3545;
    }
    
    .image-preview {
        max-width: 200px;
        max-height: 200px;
        border: 2px dashed #ddd;
        border-radius: 8px;
        padding: 10px;
        display: none;
    }
    
    .image-preview img {
        max-width: 100%;
        max-height: 150px;
    }
</style>
@endsection

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="bi bi-plus-circle"></i> Add New Product</h1>
    
    <div>
        <a href="index.php?page=products" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back to Products
        </a>
    </div>
</div>

<!-- Success/Error Messages -->
@if($error = \App\Core\Session::getFlash('error'))
<div class="alert alert-danger">
    {{ $error }}
</div>
@endif

@if($success = \App\Core\Session::getFlash('success'))
<div class="alert alert-success">
    {{ $success }}
</div>
@endif

<!-- Product Form -->
<form method="POST" action="index.php?page=products&action=store" enctype="multipart/form-data" id="productForm">
    <input type="hidden" name="csrf_token" value="{{ $csrf_token }}">
    
    <!-- Basic Information -->
    <div class="form-section">
        <h5><i class="bi bi-info-circle"></i> Basic Information</h5>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="name" class="form-label required">Product Name</label>
                <input type="text" 
                       class="form-control" 
                       id="name" 
                       name="name" 
                       required
                       maxlength="100"
                       placeholder="Enter product name">
                <div class="form-text">Maximum 100 characters</div>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="sku" class="form-label required">SKU (Stock Keeping Unit)</label>
                <input type="text" 
                       class="form-control" 
                       id="sku" 
                       name="sku" 
                       required
                       maxlength="50"
                       placeholder="e.g., PROD-001">
                <div class="form-text">Unique identifier for this product</div>
            </div>
        </div>
        
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" 
                      id="description" 
                      name="description" 
                      rows="3"
                      placeholder="Enter product description (optional)"></textarea>
            <div class="form-text">Maximum 500 characters</div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="category" class="form-label required">Category</label>
                <select class="form-control" id="category" name="category" required>
                    <option value="">Select Category</option>
                    @foreach($categories as $category)
                    <option value="{{ $category }}">{{ $category }}</option>
                    @endforeach
                    <option value="other">Other (specify below)</option>
                </select>
                <input type="text" 
                       class="form-control mt-2" 
                       id="category_other" 
                       name="category_other" 
                       placeholder="Enter new category"
                       style="display: none;">
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="supplier" class="form-label">Supplier</label>
                <input type="text" 
                       class="form-control" 
                       id="supplier" 
                       name="supplier" 
                       maxlength="100"
                       placeholder="Enter supplier name (optional)">
            </div>
        </div>
    </div>
    
    <!-- Pricing & Inventory -->
    <div class="form-section">
        <h5><i class="bi bi-cash-coin"></i> Pricing & Inventory</h5>
        
        <div class="row">
            <div class="col-md-4 mb-3">
                <label for="price" class="form-label required">Price ($)</label>
                <div class="input-group">
                    <span class="input-group-text">$</span>
                    <input type="number" 
                           class="form-control" 
                           id="price" 
                           name="price" 
                           required
                           min="0"
                           step="0.01"
                           placeholder="0.00">
                </div>
                <div class="form-text">Enter price in dollars</div>
            </div>
            
            <div class="col-md-4 mb-3">
                <label for="quantity" class="form-label required">Quantity</label>
                <input type="number" 
                       class="form-control" 
                       id="quantity" 
                       name="quantity" 
                       required
                       min="0"
                       value="0"
                       placeholder="0">
                <div class="form-text">Current stock quantity</div>
            </div>
            
            <div class="col-md-4 mb-3">
                <label for="min_stock_level" class="form-label required">Minimum Stock Level</label>
                <input type="number" 
                       class="form-control" 
                       id="min_stock_level" 
                       name="min_stock_level" 
                       required
                       min="1"
                       value="5"
                       placeholder="5">
                <div class="form-text">Low stock warning threshold</div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="location" class="form-label">Location</label>
                <select class="form-control" id="location" name="location">
                    <option value="">Select Location</option>
                    @foreach($locations as $location)
                    <option value="{{ $location }}">{{ $location }}</option>
                    @endforeach
                    <option value="other">Other (specify below)</option>
                </select>
                <input type="text" 
                       class="form-control mt-2" 
                       id="location_other" 
                       name="location_other" 
                       placeholder="Enter new location"
                       style="display: none;">
            </div>
        </div>
    </div>
    
    <!-- Image Upload (Optional) -->
    <div class="form-section">
        <h5><i class="bi bi-image"></i> Product Image (Optional)</h5>
        
        <div class="mb-3">
            <label for="image" class="form-label">Upload Image</label>
            <input type="file" 
                   class="form-control" 
                   id="image" 
                   name="image"
                   accept="image/*">
            <div class="form-text">Maximum size: 2MB. Allowed: JPG, PNG, GIF</div>
        </div>
        
        <div class="image-preview mb-3" id="imagePreview">
            <img src="" alt="Image Preview" id="previewImage">
            <div class="mt-2 text-center">
                <button type="button" class="btn btn-sm btn-danger" id="removeImage">Remove Image</button>
            </div>
        </div>
    </div>
    
    <!-- Form Actions -->
    <div class="d-flex justify-content-between mt-4">
        <a href="index.php?page=products" class="btn btn-outline-secondary">
            <i class="bi bi-x-circle"></i> Cancel
        </a>
        
        <div>
            <button type="reset" class="btn btn-outline-warning me-2">
                <i class="bi bi-arrow-clockwise"></i> Reset
            </button>
            
            <button type="submit" class="btn btn-success">
                <i class="bi bi-check-circle"></i> Save Product
            </button>
        </div>
    </div>
</form>
@endsection

@section('scripts')
<script>
// Show/hide "other" input for category
document.getElementById('category').addEventListener('change', function() {
    const otherInput = document.getElementById('category_other');
    if (this.value === 'other') {
        otherInput.style.display = 'block';
        otherInput.required = true;
    } else {
        otherInput.style.display = 'none';
        otherInput.required = false;
    }
});

// Show/hide "other" input for location
document.getElementById('location').addEventListener('change', function() {
    const otherInput = document.getElementById('location_other');
    if (this.value === 'other') {
        otherInput.style.display = 'block';
    } else {
        otherInput.style.display = 'none';
    }
});

// Image preview
document.getElementById('image').addEventListener('change', function(e) {
    const preview = document.getElementById('imagePreview');
    const previewImage = document.getElementById('previewImage');
    
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            previewImage.src = e.target.result;
            preview.style.display = 'block';
        }
        
        reader.readAsDataURL(this.files[0]);
    }
});

// Remove image
document.getElementById('removeImage').addEventListener('click', function() {
    document.getElementById('image').value = '';
    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('previewImage').src = '';
});

// Form validation
document.getElementById('productForm').addEventListener('submit', function(e) {
    const price = document.getElementById('price').value;
    const quantity = document.getElementById('quantity').value;
    const minStock = document.getElementById('min_stock_level').value;
    
    if (parseFloat(price) < 0) {
        e.preventDefault();
        alert('Price cannot be negative.');
        return;
    }
    
    if (parseInt(quantity) < 0) {
        e.preventDefault();
        alert('Quantity cannot be negative.');
        return;
    }
    
    if (parseInt(minStock) < 1) {
        e.preventDefault();
        alert('Minimum stock level must be at least 1.');
        return;
    }
    
    // Check file size (client-side)
    const imageInput = document.getElementById('image');
    if (imageInput.files[0]) {
        const fileSize = imageInput.files[0].size / 1024 / 1024; // in MB
        if (fileSize > 2) {
            e.preventDefault();
            alert('Image size must be less than 2MB.');
            return;
        }
    }
});
</script>
@endsection