@extends('layouts.master')

@section('title', 'Products - Inventory System')

@section('styles')
<style>
    .product-table th {
        cursor: pointer;
        user-select: none;
    }
    
    .product-table th:hover {
        background-color: rgba(40, 167, 69, 0.1);
    }
    
    .sort-icon {
        margin-left: 5px;
        font-size: 0.8em;
        opacity: 0.7;
    }
    
    .stock-low {
        color: #dc3545;
        font-weight: bold;
    }
    
    .stock-ok {
        color: #28a745;
    }
    
    .stock-warning {
        color: #ffc107;
        font-weight: bold;
    }

    /* Quantity Controls */
    .quantity-controls .btn {
        width: 30px;
        height: 30px;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .quantity-controls .btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }

    .quantity-display {
        font-weight: bold;
        font-size: 1.1em;
    }

    /* Flash message animation */
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Double-click hint */
    .quantity-display {
        cursor: pointer;
        user-select: none;
    }

    .quantity-display:hover {
        background-color: #f8f9fa;
        border-radius: 3px;
    }

    /* Stock status row colors */
    .stock-warning-row {
        background-color: #fff3cd !important;
    }

    .stock-warning-row:hover {
        background-color: #ffeaa7 !important;
    }
</style>
@endsection

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="bi bi-grid"></i> Product Management</h1>
    
    <div>
        <a href="index.php?page=products&action=create" class="btn btn-success">
            <i class="bi bi-plus-circle"></i> Add New Product
        </a>
    </div>
</div>

<!-- Search and Filter Bar -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <input type="hidden" name="page" value="products">
            
            <div class="col-md-6">
                <div class="input-group">
                    <input type="text" 
                           class="form-control" 
                           name="search" 
                           placeholder="Search by name, SKU, or description..."
                           value="{{ $searchTerm }}"
                           id="searchInput">
                    <button class="btn btn-outline-success" type="submit">
                        <i class="bi bi-search"></i> Search
                    </button>
                </div>
            </div>
            
            <div class="col-md-3">
                <select class="form-select" name="category">
                    <option value="">All Categories</option>
                    @foreach($categories as $category)
                    <option value="{{ $category }}" {{ $_GET['category'] == $category ? 'selected' : '' }}>
                        {{ $category }}
                    </option>
                    @endforeach
                </select>
            </div>
            
            <div class="col-md-3">
                <select class="form-select" name="location">
                    <option value="">All Locations</option>
                    @foreach($locations as $location)
                    <option value="{{ $location }}" {{ $_GET['location'] == $location ? 'selected' : '' }}>
                        {{ $location }}
                    </option>
                    @endforeach
                </select>
            </div>
            
            <div class="col-12">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="lowStock" name="low_stock" value="1" {{ $_GET['low_stock'] ? 'checked' : '' }}>
                    <label class="form-check-label" for="lowStock">
                        Show Low Stock Only
                    </label>
                </div>
                <button type="submit" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-funnel"></i> Apply Filters
                </button>
                <a href="index.php?page=products" class="btn btn-link btn-sm">Clear Filters</a>
            </div>
        </form>
    </div>
</div>

<!-- Products Table -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-box-seam"></i> Products 
            <span class="badge bg-success">{{ $totalProducts }}</span>
        </h5>
        
        <div class="text-muted">
            Page {{ $currentPage }}
        </div>
    </div>
    
    <div class="card-body p-0">
        @if(count($products) > 0)
        <div class="table-responsive">
            <table class="table table-hover mb-0 product-table">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>SKU</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($products as $product)
                    @php
                        // Stock status calculation (keep this)
                        $stockClass = '';
                        if ($product['quantity'] == 0) {
                            $stockClass = 'stock-low';
                            $stockText = 'Out of Stock';
                            $stockBadge = 'danger';
                        } elseif ($product['quantity'] < $product['min_stock_level']) {
                            $stockClass = 'stock-warning';
                            $stockText = 'Low Stock';
                            $stockBadge = 'warning';
                        } else {
                            $stockClass = 'stock-ok';
                            $stockText = 'In Stock';
                            $stockBadge = 'success';
                        }
                    @endphp
                    
                    <tr class="{{ $product['quantity'] < $product['min_stock_level'] ? 'low-stock' : '' }}">
                        <!-- Column 1: ID -->
                        <td>{{ $product['id'] }}</td>
                        
                        <!-- Column 2: Product Name -->
                        <td>
                            <strong>{{ $product['name'] }}</strong>
                            @if($product['description'])
                            <br>
                            <small class="text-muted">
                                @if(strlen($product['description']) > 50)
                                    {{ substr($product['description'], 0, 50) }}...
                                @else
                                    {{ $product['description'] }}
                                @endif
                            </small>
                            @endif
                        </td>
                        
                        <!-- Column 3: Category -->
                        <td>
                            <span class="badge bg-success">{{ $product['category'] }}</span>
                        </td>
                        
                        <!-- Column 4: Price -->
                        <td>${{ number_format($product['price'], 2) }}</td>
                        
                        <!-- Column 5: Quantity (with +- buttons) -->
                        <td class="{{ $stockClass }}" data-product-id="{{ $product['id'] }}">
                            <div class="quantity-controls d-flex align-items-center">
                                <button type="button" 
                                        class="btn btn-sm btn-outline-secondary quantity-decrease" 
                                        data-product-id="{{ $product['id'] }}"
                                        title="Decrease quantity">
                                    <i class="bi bi-dash"></i>
                                </button>
                                
                                <span class="quantity-display mx-2" 
                                    id="quantity-{{ $product['id'] }}"
                                    style="min-width: 30px; text-align: center;">
                                    {{ $product['quantity'] }}
                                </span>
                                
                                <button type="button" 
                                        class="btn btn-sm btn-outline-secondary quantity-increase" 
                                        data-product-id="{{ $product['id'] }}"
                                        title="Increase quantity">
                                    <i class="bi bi-plus"></i>
                                </button>
                            </div>
                            
                            @if($product['quantity'] < $product['min_stock_level'])
                            <small class="text-muted d-block mt-1">Min: {{ $product['min_stock_level'] }}</small>
                            @endif
                        </td>
                        
                        <!-- Column 6: SKU -->
                        <td><code>{{ $product['sku'] }}</code></td>
                        
                        <!-- Column 7: Location -->
                        <td>{{ $product['location'] }}</td>
                        
                        <!-- Column 8: Status -->
                        <td>
                            <span class="badge bg-{{ $stockBadge }}">{{ $stockText }}</span>
                        </td>
                        
                        <!-- Column 9: Actions -->
                        <td>
                            <div class="btn-group btn-group-sm" role="group">
                                <a href="index.php?page=products&action=edit&id={{ $product['id'] }}" 
                                class="btn btn-outline-primary" 
                                title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                
                                <button type="button" 
                                        class="btn btn-outline-danger delete-product" 
                                        data-id="{{ $product['id'] }}"
                                        data-name="{{ $product['name'] }}"
                                        title="Delete">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        @if($totalProducts > 10)
        <nav class="p-3 border-top">
            <ul class="pagination justify-content-center mb-0">
                @if($currentPage > 1)
                <li class="page-item">
                    <a class="page-link" href="index.php?page=products&p={{ $currentPage - 1 }}{{ $searchTerm ? '&search=' . urlencode($searchTerm) : '' }}">
                        Previous
                    </a>
                </li>
                @endif
                
                @for($i = 1; $i <= ceil($totalProducts / 10); $i++)
                <li class="page-item {{ $i == $currentPage ? 'active' : '' }}">
                    <a class="page-link" href="index.php?page=products&p={{ $i }}{{ $searchTerm ? '&search=' . urlencode($searchTerm) : '' }}">
                        {{ $i }}
                    </a>
                </li>
                @endfor
                
                @if($currentPage < ceil($totalProducts / 10))
                <li class="page-item">
                    <a class="page-link" href="index.php?page=products&p={{ $currentPage + 1 }}{{ $searchTerm ? '&search=' . urlencode($searchTerm) : '' }}">
                        Next
                    </a>
                </li>
                @endif
            </ul>
        </nav>
        @endif
        
        @else
        <div class="text-center py-5">
            <i class="bi bi-inbox display-1 text-muted"></i>
            <h4 class="mt-3">No products found</h4>
            <p class="text-muted">
                @if($searchTerm)
                No products match your search "{{ $searchTerm }}".
                @else
                Your product inventory is empty.
                @endif
            </p>
            <a href="index.php?page=products&action=create" class="btn btn-success">
                <i class="bi bi-plus-circle"></i> Add Your First Product
            </a>
        </div>
        @endif
    </div>
</div>

<!-- Quick Stats -->
<div class="row mt-4">
    <div class="col-md-3">
        <div class="card bg-light">
            <div class="card-body text-center">
                <h6 class="text-muted">Total Products</h6>
                <h3 class="text-success">{{ $totalProducts }}</h3>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        @php
            $lowStockCount = 0;
            foreach ($products as $product) {
                if ($product['quantity'] < $product['min_stock_level']) {
                    $lowStockCount++;
                }
            }
        @endphp
        <div class="card bg-light">
            <div class="card-body text-center">
                <h6 class="text-muted">Low Stock</h6>
                <h3 class="text-warning">{{ $lowStockCount }}</h3>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        @php
            $outOfStockCount = 0;
            foreach ($products as $product) {
                if ($product['quantity'] == 0) {
                    $outOfStockCount++;
                }
            }
        @endphp
        <div class="card bg-light">
            <div class="card-body text-center">
                <h6 class="text-muted">Out of Stock</h6>
                <h3 class="text-danger">{{ $outOfStockCount }}</h3>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card bg-light">
            <div class="card-body text-center">
                <h6 class="text-muted">Categories</h6>
                <h3 class="text-info">{{ count($categories) }}</h3>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
// Delete product confirmation
document.querySelectorAll('.delete-product').forEach(button => {
    button.addEventListener('click', function() {
        const productId = this.getAttribute('data-id');
        const productName = this.getAttribute('data-name');
        
        if (confirm(`Are you sure you want to delete "${productName}"? This action cannot be undone.`)) {
            // In next step, we'll implement AJAX delete
            window.location.href = `index.php?page=products&action=delete&id=${productId}&csrf_token={{ $csrf_token }}`;
        }
    });
});

// Live Quantity Update with AJAX
document.querySelectorAll('.quantity-increase, .quantity-decrease').forEach(button => {
    button.addEventListener('click', async function() {
        const productId = this.getAttribute('data-product-id');
        const isIncrease = this.classList.contains('quantity-increase');
        const quantityDisplay = document.getElementById(`quantity-${productId}`);
        const currentQuantity = parseInt(quantityDisplay.textContent);
        const row = this.closest('tr');
        
        // Calculate new quantity
        let newQuantity = currentQuantity;
        if (isIncrease) {
            newQuantity = currentQuantity + 1;
        } else {
            newQuantity = Math.max(0, currentQuantity - 1); // Don't go below 0
        }
        
        // Show loading state
        const originalContent = quantityDisplay.innerHTML;
        quantityDisplay.innerHTML = '<span class="spinner-border spinner-border-sm text-success"></span>';
        this.disabled = true;
        
        try {
            // Send AJAX request
            const response = await fetch('ajax-update-quantity.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'  // ADD THIS LINE
                },
                body: `product_id=${productId}&quantity=${newQuantity}&action=${isIncrease ? 'increment' : 'decrement'}&csrf_token={{ $csrf_token }}`
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Update display
                quantityDisplay.textContent = data.product.quantity;
                
                // Update row styling based on stock status
                updateRowStockStatus(row, data.product);
                
                // Show success message
                showFlashMessage(`Quantity updated for "${data.product.name}"`, 'success');
                
            } else {
                // Revert display on error
                quantityDisplay.textContent = currentQuantity;
                showFlashMessage(`Error: ${data.error}`, 'danger');
            }
            
        } catch (error) {
            // Revert display on network error
            quantityDisplay.textContent = currentQuantity;
            showFlashMessage('Network error. Please try again.', 'danger');
            console.error('AJAX error:', error);
            
        } finally {
            // Re-enable button
            this.disabled = false;
        }
    });
});

// Function to update row styling based on stock status
function updateRowStockStatus(row, product) {
    // Remove existing stock classes
    row.classList.remove('low-stock', 'stock-warning-row');
    
    // Update quantity cell class
    const quantityCell = row.querySelector('td[data-product-id]');
    if (quantityCell) {
        quantityCell.className = ''; // Clear classes
        quantityCell.classList.add(product.stock_class);
    }
    
    // Update status badge
    const statusBadge = row.querySelector('.badge');
    if (statusBadge) {
        statusBadge.className = 'badge'; // Reset classes
        
        switch(product.stock_status) {
            case 'out_of_stock':
                statusBadge.classList.add('bg-danger');
                statusBadge.textContent = 'Out of Stock';
                row.classList.add('low-stock');
                break;
            case 'low_stock':
                statusBadge.classList.add('bg-warning', 'text-dark');
                statusBadge.textContent = 'Low Stock';
                row.classList.add('low-stock');
                break;
            default:
                statusBadge.classList.add('bg-success');
                statusBadge.textContent = 'In Stock';
        }
    }
}

// Function to show flash messages
function showFlashMessage(message, type) {
    // Remove existing flash messages
    document.querySelectorAll('.ajax-flash').forEach(el => el.remove());
    
    // Create new flash message
    const flashDiv = document.createElement('div');
    flashDiv.className = `alert alert-${type} alert-dismissible fade show ajax-flash`;
    flashDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    
    flashDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(flashDiv);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        if (flashDiv.parentNode) {
            flashDiv.remove();
        }
    }, 3000);
}

// Add direct quantity edit (double-click to edit)
document.querySelectorAll('.quantity-display').forEach(display => {
    display.addEventListener('dblclick', function() {
        const productId = this.id.replace('quantity-', '');
        const currentValue = this.textContent;
        
        // Replace with input field
        const input = document.createElement('input');
        input.type = 'number';
        input.min = '0';
        input.value = currentValue;
        input.className = 'form-control form-control-sm';
        input.style.width = '70px';
        input.style.textAlign = 'center';
        
        this.innerHTML = '';
        this.appendChild(input);
        input.focus();
        input.select();
        
        // Handle input completion
        const handleComplete = async () => {
            const newValue = parseInt(input.value);
            if (isNaN(newValue) || newValue < 0) {
                this.textContent = currentValue;
                return;
            }
            
            if (newValue === parseInt(currentValue)) {
                this.textContent = currentValue;
                return;
            }
            
            // Show loading
            this.innerHTML = '<span class="spinner-border spinner-border-sm text-success"></span>';
            
            try {
                const response = await fetch('ajax-update-quantity.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `product_id=${productId}&quantity=${newValue}&action=set&csrf_token={{ $csrf_token }}`
                });
                
                const data = await response.json();
                
                if (data.success) {
                    this.textContent = data.product.quantity;
                    const row = this.closest('tr');
                    updateRowStockStatus(row, data.product);
                    showFlashMessage(`Quantity set to ${data.product.quantity} for "${data.product.name}"`, 'success');
                } else {
                    this.textContent = currentValue;
                    showFlashMessage(`Error: ${data.error}`, 'danger');
                }
                
            } catch (error) {
                this.textContent = currentValue;
                showFlashMessage('Network error. Please try again.', 'danger');
            }
        };
        
        input.addEventListener('blur', handleComplete);
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleComplete();
            }
        });
    });
});

// AJAX Autocomplete Search (for next step)
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('input', function() {
        // We'll implement AJAX autocomplete in next step
    });
}
</script>
@endsection