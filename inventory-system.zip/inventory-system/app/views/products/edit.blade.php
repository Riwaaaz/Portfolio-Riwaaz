@extends('layouts.master')

@section('title', 'Edit Product - Inventory System')

@section('styles')
<style>
    .form-section {
        background: #f8f9fa;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        border-left: 4px solid var(--primary-green);
    }
    
    .form-section h5 {
        color: var(--text-dark);
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #dee2e6;
    }
    
    .required::after {
        content: " *";
        color: #dc3545;
    }
    
    .current-image {
        max-width: 200px;
        max-height: 200px;
        border: 2px solid #dee2e6;
        border-radius: 8px;
        padding: 10px;
    }
    
    .current-image img {
        max-width: 100%;
        max-height: 150px;
    }
</style>
@endsection

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="bi bi-pencil"></i> Edit Product: {{ $product['name'] }}</h1>
    
    <div>
        <a href="index.php?page=products" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back to Products
        </a>
    </div>
</div>

<!-- Success/Error Messages -->
@if($error = \App\Core\Session::getFlash('error'))
<div class="alert alert-danger">
    {{ $error }}
</div>
@endif

<!-- Product Form -->
<form method="POST" action="index.php?page=products&action=update&id={{ $product['id'] }}" enctype="multipart/form-data" id="productForm">
    <input type="hidden" name="csrf_token" value="{{ $csrf_token }}">
    <input type="hidden" name="current_image" value="{{ $product['image_url'] }}">
    
    <!-- Basic Information -->
    <div class="form-section">
        <h5><i class="bi bi-info-circle"></i> Basic Information</h5>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="name" class="form-label required">Product Name</label>
                <input type="text" 
                       class="form-control" 
                       id="name" 
                       name="name" 
                       required
                       maxlength="100"
                       value="{{ $product['name'] }}"
                       placeholder="Enter product name">
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="sku" class="form-label required">SKU (Stock Keeping Unit)</label>
                <input type="text" 
                       class="form-control" 
                       id="sku" 
                       name="sku" 
                       required
                       maxlength="50"
                       value="{{ $product['sku'] }}"
                       placeholder="e.g., PROD-001">
                <div class="form-text">Unique identifier for this product</div>
            </div>
        </div>
        
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" 
                      id="description" 
                      name="description" 
                      rows="3"
                      placeholder="Enter product description">{{ $product['description'] }}</textarea>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="category" class="form-label required">Category</label>
                <select class="form-control" id="category" name="category" required>
                    <option value="">Select Category</option>
                    @foreach($categories as $category)
                    <option value="{{ $category }}" {{ $product['category'] == $category ? 'selected' : '' }}>
                        {{ $category }}
                    </option>
                    @endforeach
                    <option value="other" {{ !in_array($product['category'], $categories) ? 'selected' : '' }}>
                        Other (specify below)
                    </option>
                </select>
                <input type="text" 
                       class="form-control mt-2" 
                       id="category_other" 
                       name="category_other" 
                       value="{{ !in_array($product['category'], $categories) ? $product['category'] : '' }}"
                       placeholder="Enter new category"
                       style="{{ !in_array($product['category'], $categories) ? 'display: block;' : 'display: none;' }}">
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="supplier" class="form-label">Supplier</label>
                <input type="text" 
                       class="form-control" 
                       id="supplier" 
                       name="supplier" 
                       maxlength="100"
                       value="{{ $product['supplier'] }}"
                       placeholder="Enter supplier name">
            </div>
        </div>
    </div>
    
    <!-- Pricing & Inventory -->
    <div class="form-section">
        <h5><i class="bi bi-cash-coin"></i> Pricing & Inventory</h5>
        
        <div class="row">
            <div class="col-md-4 mb-3">
                <label for="price" class="form-label required">Price ($)</label>
                <div class="input-group">
                    <span class="input-group-text">$</span>
                    <input type="number" 
                           class="form-control" 
                           id="price" 
                           name="price" 
                           required
                           min="0"
                           step="0.01"
                           value="{{ $product['price'] }}">
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <label for="quantity" class="form-label required">Quantity</label>
                <input type="number" 
                       class="form-control" 
                       id="quantity" 
                       name="quantity" 
                       required
                       min="0"
                       value="{{ $product['quantity'] }}">
                <div class="form-text">Current stock quantity</div>
            </div>
            
            <div class="col-md-4 mb-3">
                <label for="min_stock_level" class="form-label required">Minimum Stock Level</label>
                <input type="number" 
                       class="form-control" 
                       id="min_stock_level" 
                       name="min_stock_level" 
                       required
                       min="1"
                       value="{{ $product['min_stock_level'] }}">
                <div class="form-text">Low stock warning threshold</div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="location" class="form-label">Location</label>
                <select class="form-control" id="location" name="location">
                    <option value="">Select Location</option>
                    @foreach($locations as $location)
                    <option value="{{ $location }}" {{ $product['location'] == $location ? 'selected' : '' }}>
                        {{ $location }}
                    </option>
                    @endforeach
                    <option value="other" {{ !in_array($product['location'], $locations) ? 'selected' : '' }}>
                        Other (specify below)
                    </option>
                </select>
                <input type="text" 
                       class="form-control mt-2" 
                       id="location_other" 
                       name="location_other" 
                       value="{{ !in_array($product['location'], $locations) ? $product['location'] : '' }}"
                       placeholder="Enter new location"
                       style="{{ !in_array($product['location'], $locations) ? 'display: block;' : 'display: none;' }}">
            </div>
        </div>
    </div>
    
    <!-- Image Upload -->
    <div class="form-section">
        <h5><i class="bi bi-image"></i> Product Image</h5>
        
        @if($product['image_url'])
        <div class="mb-3">
            <label class="form-label">Current Image</label>
            <div class="current-image">
                <img src="uploads/{{ $product['image_url'] }}" alt="{{ $product['name'] }}">
            </div>
            <div class="form-check mt-2">
                <input class="form-check-input" type="checkbox" id="remove_current_image" name="remove_current_image">
                <label class="form-check-label" for="remove_current_image">
                    Remove current image
                </label>
            </div>
        </div>
        @endif
        
        <div class="mb-3">
            <label for="image" class="form-label">
                @if($product['image_url'])
                Replace Image
                @else
                Upload Image
                @endif
            </label>
            <input type="file" 
                   class="form-control" 
                   id="image" 
                   name="image"
                   accept="image/*">
            <div class="form-text">Maximum size: 2MB. Allowed: JPG, PNG, GIF</div>
        </div>
    </div>
    
    <!-- Form Actions -->
    <div class="d-flex justify-content-between mt-4">
        <a href="index.php?page=products" class="btn btn-outline-secondary">
            <i class="bi bi-x-circle"></i> Cancel
        </a>
        
        <div>
            <button type="submit" class="btn btn-success me-2">
                <i class="bi bi-check-circle"></i> Update Product
            </button>
            
            <button type="button" class="btn btn-danger" id="deleteBtn">
                <i class="bi bi-trash"></i> Delete Product
            </button>
        </div>
    </div>
</form>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete "<strong>{{ $product['name'] }}</strong>"? 
                This action cannot be undone.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <a href="index.php?page=products&action=delete&id={{ $product['id'] }}&csrf_token={{ $csrf_token }}" 
                   class="btn btn-danger">
                    Yes, Delete Product
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
// Show/hide "other" input for category
document.getElementById('category').addEventListener('change', function() {
    const otherInput = document.getElementById('category_other');
    if (this.value === 'other') {
        otherInput.style.display = 'block';
        otherInput.required = true;
    } else {
        otherInput.style.display = 'none';
        otherInput.required = false;
    }
});

// Show/hide "other" input for location
document.getElementById('location').addEventListener('change', function() {
    const otherInput = document.getElementById('location_other');
    if (this.value === 'other') {
        otherInput.style.display = 'block';
    } else {
        otherInput.style.display = 'none';
    }
});

// Delete confirmation
document.getElementById('deleteBtn').addEventListener('click', function() {
    const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
    deleteModal.show();
});

// Form validation
document.getElementById('productForm').addEventListener('submit', function(e) {
    const price = document.getElementById('price').value;
    const quantity = document.getElementById('quantity').value;
    const minStock = document.getElementById('min_stock_level').value;
    
    if (parseFloat(price) < 0) {
        e.preventDefault();
        alert('Price cannot be negative.');
        return;
    }
    
    if (parseInt(quantity) < 0) {
        e.preventDefault();
        alert('Quantity cannot be negative.');
        return;
    }
    
    if (parseInt(minStock) < 1) {
        e.preventDefault();
        alert('Minimum stock level must be at least 1.');
        return;
    }
});
</script>
@endsection