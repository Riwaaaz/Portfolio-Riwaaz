@extends('layouts.master')

@section('title', 'Inventory System - Manage Your Products')

@section('main-class', 'container-fluid px-0')

@section('styles')
<style>
    /* Landing page specific styles */
    .hero-section {
        background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        color: white;
        padding: 100px 0;
        text-align: center;
    }
    
    .hero-section h1 {
        font-size: 3.5rem;
        font-weight: bold;
        margin-bottom: 1rem;
    }
    
    .hero-section p {
        font-size: 1.25rem;
        max-width: 700px;
        margin: 0 auto 2rem;
        opacity: 0.9;
    }
    
    .features-section {
        padding: 80px 0;
        background: #f8f9fa;
    }
    
    .feature-card {
        background: white;
        border-radius: 10px;
        padding: 30px;
        height: 100%;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        transition: transform 0.3s;
    }
    
    .feature-card:hover {
        transform: translateY(-5px);
    }
    
    .feature-icon {
        font-size: 3rem;
        color: #28a745;
        margin-bottom: 1rem;
    }
    
    .cta-section {
        padding: 80px 0;
        text-align: center;
    }
    
    .login-box {
        max-width: 400px;
        margin: 0 auto;
        padding: 40px;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        background: white;
    }
    
    .demo-credentials {
        background: #e9ffe9;
        border-left: 4px solid #28a745;
        padding: 15px;
        border-radius: 5px;
        margin-top: 20px;
    }
</style>
@endsection

@section('content')
<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <h1><i class="bi bi-box-seam"></i> Inventory Management System</h1>
        <p class="lead">A complete solution to manage your products, track inventory, and optimize your stock levels with real-time updates and security features.</p>
        
        <div class="mt-4">
            <a href="index.php?page=login" class="btn btn-light btn-lg me-3">
                <i class="bi bi-box-arrow-in-right"></i> Login to Dashboard
            </a>
            <a href="#features" class="btn btn-outline-light btn-lg">
                <i class="bi bi-info-circle"></i> Learn More
            </a>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features-section" id="features">
    <div class="container">
        <h2 class="text-center mb-5">Powerful Features for Inventory Management</h2>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <h4>Secure & Protected</h4>
                    <p>Enterprise-grade security with CSRF protection, SQL injection prevention, and secure session management.</p>
                    <ul class="list-unstyled">
                        <li><i class="bi bi-check text-success"></i> Password hashing</li>
                        <li><i class="bi bi-check text-success"></i> XSS prevention</li>
                        <li><i class="bi bi-check text-success"></i> Session security</li>
                    </ul>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="bi bi-speedometer2"></i>
                    </div>
                    <h4>Real-Time Dashboard</h4>
                    <p>Monitor your inventory with live statistics, low stock alerts, and quick insights into your product data.</p>
                    <ul class="list-unstyled">
                        <li><i class="bi bi-check text-success"></i> Live quantity updates</li>
                        <li><i class="bi bi-check text-success"></i> Stock level warnings</li>
                        <li><i class="bi bi-check text-success"></i> Inventory value tracking</li>
                    </ul>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="bi bi-browser-edge"></i>
                    </div>
                    <h4>Modern Technology</h4>
                    <p>Built with latest PHP, MySQL, Bootstrap 5, and AJAX for a seamless user experience.</p>
                    <ul class="list-unstyled">
                        <li><i class="bi bi-check text-success"></i> Responsive design</li>
                        <li><i class="bi bi-check text-success"></i> AJAX live updates</li>
                        <li><i class="bi bi-check text-success"></i> Blade templates</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="cta-section">
    <div class="container">
        <h2 class="mb-4">Ready to Manage Your Inventory?</h2>
        <p class="lead mb-5">Login to access the full dashboard and start managing your products efficiently.</p>
        
        <div class="login-box">
            <h4 class="mb-4">Login to System</h4>
            
            <form method="POST" action="index.php?page=login">
                <input type="hidden" name="csrf_token" value="{{ $csrf_token }}">
                
                <div class="mb-3">
                    <label class="form-label">Username or Email</label>
                    <input type="text" class="form-control" name="username" placeholder="Enter username" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Enter password" required>
                </div>
                
                <button type="submit" class="btn btn-success w-100 btn-lg">
                    <i class="bi bi-box-arrow-in-right"></i> Login to Dashboard
                </button>
            </form>
            
            <div class="demo-credentials mt-4">
                <h6><i class="bi bi-key"></i> Demo Credentials</h6>
                <p class="mb-1"><strong>Admin:</strong> admin / admin123</p>
                <p class="mb-0"><small>Full access to all features</small></p>
            </div>
        </div>
        
        <div class="mt-5">
            <h5>Built for Educational Purposes</h5>
            <p class="text-muted">This system demonstrates full-stack web development with PHP, MySQL, and modern web technologies.</p>
            <small class="text-muted">© {{ date('Y') }} Inventory System - Final Year Project</small>
        </div>
    </div>
</section>
@endsection

@section('scripts')
<script>
// Smooth scroll for Learn More button
document.querySelector('a[href="#features"]').addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector('#features').scrollIntoView({
        behavior: 'smooth'
    });
});
</script>
@endsection

<?php
// Tell master layout to hide navbar on landing page
$hideNavbar = true;
?>