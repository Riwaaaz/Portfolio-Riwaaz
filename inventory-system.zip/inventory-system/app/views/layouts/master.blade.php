<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Inventory System')</title>
    
    <!-- Bootstrap 5 CSS with Green Theme -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    
    @yield('styles')
</head>
<body>
    <!-- Navigation Bar (will be hidden on login page) -->
    @if(!isset($hideNavbar) || !$hideNavbar)
    <nav class="navbar navbar-expand-lg navbar-dark bg-success">
        <div class="container">
            <a class="navbar-brand" href="index.php?page=dashboard"">
                <i class="bi bi-box-seam"></i> Inventory System
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                        @if(\App\Core\Session::isLoggedIn())
                            @php
                                $currentPage = $_GET['page'] ?? 'dashboard';
                            @endphp
                            
                            <li class="nav-item">
                                <a class="nav-link {{ $currentPage == 'dashboard' ? 'active' : '' }}" 
                                href="index.php?page=dashboard">
                                    <i class="bi bi-speedometer2"></i> Dashboard
                                    @if($currentPage == 'dashboard')<span class="visually-hidden">(current)</span>@endif
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ $currentPage == 'products' ? 'active' : '' }}" 
                                href="index.php?page=products">
                                    <i class="bi bi-grid"></i> Products
                                    @if($currentPage == 'products')<span class="visually-hidden">(current)</span>@endif
                                </a>
                            </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle"></i> {{ \App\Core\Session::get('user_username') }}
                            </a>
                            <ul class="dropdown-menu">
                                <li><span class="dropdown-item-text text-muted">
                                    Role: {{ \App\Core\Session::get('user_role') }}
                                </span></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item" href="#" onclick="confirmLogout(event)">
                                        <i class="bi bi-box-arrow-right"></i> Logout
                                    </a>

                                    <script>
                                    function confirmLogout(event) {
                                        event.preventDefault();
                                        if (confirm('Are you sure you want to logout?')) {
                                            window.location.href = 'logout.php';
                                        }
                                    }
                                    </script>
                                </li>
                            </ul>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?page=login">
                                <i class="bi bi-box-arrow-in-right"></i> Login
                            </a>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav>
    @endif
    
    <!-- Flash Messages -->
    @if(\App\Core\Session::has('flash'))
    <div class="container mt-3">
        @foreach(\App\Core\Session::get('flash') as $type => $message)
        <div class="alert alert-{{ $type == 'error' ? 'danger' : 'success' }} alert-dismissible fade show">
            {{ $message }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        @endforeach
    </div>
    @endif
    
    <!-- Main Content -->
    <main class="@yield('main-class', 'container mt-4')">
        @yield('content')
    </main>
    
    <!-- Footer -->
    <footer class="mt-5 py-3 bg-light border-top">
        <div class="container text-center text-muted">
            <small>Inventory System &copy; {{ date('Y') }} | Built with PHP, MySQL & Bootstrap</small>
        </div>
    </footer>
    
    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script src="js/app.js"></script>

    @yield('scripts')
    
        <!-- Session Timeout Warning -->
    <script>
    // Only show timeout warning if user is logged in
    @if(\App\Core\Session::isLoggedIn())
    // Session timeout warning (15 minutes)
    setTimeout(function() {
        const warning = document.createElement('div');
        warning.id = 'session-warning';
        warning.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ffc107;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            z-index: 9999;
            max-width: 300px;
            animation: fadeIn 0.3s ease;
        `;
        warning.innerHTML = `
            <strong><i class="bi bi-exclamation-triangle"></i> Session Expiring Soon</strong>
            <p>Your session will expire in 5 minutes. Click <a href="#" onclick="refreshSession()" style="color: #856404; text-decoration: underline;">here</a> to stay logged in.</p>
            <button onclick="this.parentElement.remove()" style="background: none; border: none; float:right; font-size: 20px; cursor: pointer;">×</button>
        `;
        document.body.appendChild(warning);
        
        // Auto-remove after 4 minutes 30 seconds
        setTimeout(() => {
            if (warning.parentNode) {
                warning.remove();
            }
        }, 4.5 * 60 * 1000);
        
    }, 15 * 60 * 1000); // Show after 15 minutes of inactivity --> Change this to 10 * 1000 for a quick demo
    
    function refreshSession() {
        // Make a simple request to refresh session
        fetch('index.php?page=dashboard', {
            credentials: 'same-origin' // Send cookies
        })
        .then(() => {
            const warning = document.getElementById('session-warning');
            if (warning) {
                warning.style.animation = 'fadeOut 0.3s ease';
                setTimeout(() => warning.remove(), 300);
            }
            // Show confirmation
            const success = document.createElement('div');
            success.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #28a745;
                color: white;
                padding: 10px;
                border-radius: 5px;
                z-index: 9999;
                animation: fadeIn 0.3s ease;
            `;
            success.innerHTML = '<i class="bi bi-check-circle"></i> Session refreshed!';
            document.body.appendChild(success);
            setTimeout(() => success.remove(), 2000);
        })
        .catch(error => {
            console.error('Session refresh error:', error);
        });
    }
    
    // Add fade animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeOut {
            from { opacity: 1; transform: translateY(0); }
            to { opacity: 0; transform: translateY(-10px); }
        }
    `;
    document.head.appendChild(style);
    @endif
    </script>
    
</body>
</html>