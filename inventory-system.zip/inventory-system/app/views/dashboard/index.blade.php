@extends('layouts.master')

@section('title', 'Dashboard - Inventory System')

@section('content')
<h1 class="mb-4">
    <i class="bi bi-speedometer2"></i> Dashboard
    <small class="text-muted fs-6">Welcome back, {{ \App\Core\Session::get('user_username') }}!</small>
</h1>

<!-- Stats Cards -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-2">Total Products</h6>
                        <h2 class="stat-number mb-0">{{ $totalProducts }}</h2>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-box-seam"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-2">Low Stock</h6>
                        <h2 class="stat-number mb-0 text-warning">{{ $lowStock }}</h2>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-2">Total Value</h6>
                        <h2 class="stat-number mb-0">${{ $totalValue }}</h2>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-currency-dollar"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-2">Your Role</h6>
                        <h2 class="stat-number mb-0 text-capitalize">
                            {{ \App\Core\Session::get('user_role') }}
                        </h2>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-person-badge"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-lightning"></i> Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="d-flex flex-wrap gap-2">
                <a href="index.php?page=products&action=create" class="btn btn-success">
                    <i class="bi bi-plus-circle"></i> Add New Product
                </a>
                <a href="index.php?page=products" class="btn btn-outline-success">
                    <i class="bi bi-grid"></i> View All Products
                </a>
                <a href="index.php?page=products" class="btn btn-outline-success">
                    <i class="bi bi-search"></i> Search Products
                </a>
                @if(\App\Core\Session::hasRole('admin'))
                <a href="index.php?page=users" class="btn btn-outline-success">
                    <i class="bi bi-people"></i> Manage Users
                </a>
                @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Products -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-clock-history"></i> Recently Added Products</h5>
            </div>
            <div class="card-body">
                @if(count($recentProducts) > 0)
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($recentProducts as $product)
                            <tr class="{{ $product['quantity'] < 10 ? 'low-stock' : '' }}">
                                <td>{{ $product['name'] }}</td>
                                <td>
                                    <span class="badge bg-success">{{ $product['category'] }}</span>
                                </td>
                                <td>${{ number_format($product['price'], 2) }}</td>
                                <td>{{ $product['quantity'] }}</td>
                                <td>
                                    @if($product['quantity'] == 0)
                                        <span class="badge bg-danger">Out of Stock</span>
                                    @elseif($product['quantity'] < 10)
                                        <span class="badge bg-warning text-dark">Low Stock</span>
                                    @else
                                        <span class="badge bg-success">In Stock</span>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                @else
                <div class="text-center py-4">
                    <i class="bi bi-inbox display-1 text-muted"></i>
                    <p class="lead mt-3">No products found. Add your first product!</p>
                    <a href="index.php?page=products&action=create" class="btn btn-success">
                        <i class="bi bi-plus-circle"></i> Add First Product
                    </a>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection