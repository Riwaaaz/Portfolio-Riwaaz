<?php
namespace App\Models;

use App\Core\Database;

/**
 * Product Model - Handles all database operations for products
 */
class Product
{
    private $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * Get all products with optional pagination
     */
    public function getAll($page = 1, $perPage = 10)
    {
        $offset = ($page - 1) * $perPage;
        
        $sql = "SELECT * FROM products ORDER BY created_at DESC LIMIT ? OFFSET ?";
        return $this->db->fetchAll($sql, [$perPage, $offset]);
    }
    
    /**
     * Get product by ID
     */
    public function getById($id)
    {
        $sql = "SELECT * FROM products WHERE id = ?";
        return $this->db->fetchOne($sql, [$id]);
    }
    
    /**
     * Create new product
     */
    public function create($data)
    {
        $sql = "INSERT INTO products (name, description, category, price, quantity, sku, supplier, location, min_stock_level, image_url) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        return $this->db->executeQuery($sql, [
            $data['name'],
            $data['description'],
            $data['category'],
            $data['price'],
            $data['quantity'],
            $data['sku'],
            $data['supplier'],
            $data['location'],
            $data['min_stock_level'],
            $data['image_url'] ?? null
        ]);
    }
    
    /**
     * Update product
     */
    public function update($id, $data)
    {
        $sql = "UPDATE products SET 
                name = ?, description = ?, category = ?, price = ?, 
                quantity = ?, sku = ?, supplier = ?, location = ?, 
                min_stock_level = ?, image_url = ? 
                WHERE id = ?";
        
        return $this->db->executeQuery($sql, [
            $data['name'],
            $data['description'],
            $data['category'],
            $data['price'],
            $data['quantity'],
            $data['sku'],
            $data['supplier'],
            $data['location'],
            $data['min_stock_level'],
            $data['image_url'] ?? null,
            $id
        ]);
    }
    
    /**
     * Delete product
     */
    public function delete($id)
    {
        $sql = "DELETE FROM products WHERE id = ?";
        return $this->db->executeQuery($sql, [$id]);
    }
    
    /**
     * Search products by name, SKU, or description
     */
    public function search($term, $page = 1, $perPage = 10)
    {
        $offset = ($page - 1) * $perPage;
        $searchTerm = "%" . $term . "%";
        
        $sql = "SELECT * FROM products 
                WHERE name LIKE ? OR sku LIKE ? OR description LIKE ? 
                ORDER BY created_at DESC 
                LIMIT ? OFFSET ?";
        
        return $this->db->fetchAll($sql, [$searchTerm, $searchTerm, $searchTerm, $perPage, $offset]);
    }
    
    /**
     * Get products by category
     */
    public function getByCategory($category)
    {
        $sql = "SELECT * FROM products WHERE category = ? ORDER BY name";
        return $this->db->fetchAll($sql, [$category]);
    }
    
    /**
     * Get low stock products
     */
    public function getLowStock()
    {
        $sql = "SELECT * FROM products WHERE quantity < min_stock_level ORDER BY quantity ASC";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * Get total count of products
     */
    public function getTotalCount()
    {
        $result = $this->db->fetchOne("SELECT COUNT(*) as count FROM products");
        return $result['count'];
    }
    
    /**
     * Get categories for dropdown
     */
    public function getCategories()
    {
        $sql = "SELECT DISTINCT category FROM products ORDER BY category";
        $results = $this->db->fetchAll($sql);
        
        $categories = [];
        foreach ($results as $row) {
            $categories[] = $row['category'];
        }
        
        // Add default categories if table is empty
        if (empty($categories)) {
            $categories = ['Electronics', 'Furniture', 'Kitchen', 'Clothing', 'Books', 'Other'];
        }
        
        return $categories;
    }
    
    /**
     * Get locations for dropdown
     */
    public function getLocations()
    {
        $sql = "SELECT DISTINCT location FROM products WHERE location IS NOT NULL ORDER BY location";
        $results = $this->db->fetchAll($sql);
        
        $locations = [];
        foreach ($results as $row) {
            $locations[] = $row['location'];
        }
        
        // Add default locations if empty
        if (empty($locations)) {
            $locations = ['Warehouse A', 'Warehouse B', 'Warehouse C', 'Storage Room'];
        }
        
        return $locations;
    }
}