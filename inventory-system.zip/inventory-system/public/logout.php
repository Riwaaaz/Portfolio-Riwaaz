<?php
// Logout Handler
require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Session;
use App\Core\Auth;

// Start session
Session::start();

// Logout user
$auth = new Auth();
$auth->logout();

// Clear remember me cookie
setcookie('remember_user', '', time() - 3600, "/");

// Redirect to login with message
Session::flash('success', 'You have been logged out successfully.');
header('Location: index.php?page=login');
exit;