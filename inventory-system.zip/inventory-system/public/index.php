<?php

// Debug: Check session consistency ---> I created this to check if the session and CSRF tokens are working correctly and figured out that they were not. 
// The token was being created before the session.
session_start();

// Front Controller - All requests go through here
require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Session;
use App\Core\Database;

// Start secure session
Session::start();

// Initialize Blade template engine
$views = __DIR__ . '/../app/views';
$cache = __DIR__ . '/../cache';

if (!is_dir($cache)) {
    mkdir($cache, 0755, true);
}

$blade = new Jenssegers\Blade\Blade($views, $cache);

// Simple routing based on query parameters
$page = $_GET['page'] ?? 'home'; // Changed from 'dashboard' to 'home'
$action = $_GET['action'] ?? 'index';

// If not logged in and trying to access protected pages, redirect to login
$protectedPages = ['dashboard', 'products', 'users'];
if (!Session::isLoggedIn() && in_array($page, $protectedPages)) {
    Session::flash('error', 'Please login to access this page.');
    header('Location: index.php?page=login');
    exit;
}

// Generate CSRF token for forms (only if not already set)
if (!Session::has('csrf_token')) {
    $csrf_token = bin2hex(random_bytes(32));
    Session::set('csrf_token', $csrf_token);
} else {
    $csrf_token = Session::get('csrf_token');
}

// Route to appropriate controller/action
switch ($page) {

case 'home':
    // Landing page - show to everyone
    echo $blade->make('home.index', [
        'csrf_token' => $csrf_token,
        'hideNavbar' => true  // Hide navbar on landing page
    ]);
    break;

case 'login':
    // If already logged in, redirect to dashboard
    if (Session::isLoggedIn()) {
        header('Location: /~np03cs4a240250/inventory-system/public/index.php?page=dashboard');
        exit;
    }
    
    echo $blade->make('auth.login', ['csrf_token' => $csrf_token, 'hideNavbar' => true]);
    break;
        
    case 'dashboard':
        // Require authentication for dashboard
        Session::requireAuth();
        
        // Get dashboard stats
        $db = Database::getInstance();
        
        // Total products
        $totalProducts = $db->fetchOne("SELECT COUNT(*) as count FROM products")['count'];
        
        // Low stock items
        $lowStock = $db->fetchOne("
            SELECT COUNT(*) as count 
            FROM products 
            WHERE quantity < min_stock_level
        ")['count'];
        
        // Total inventory value
        $totalValue = $db->fetchOne("
            SELECT SUM(price * quantity) as total 
            FROM products
        ")['total'] ?? 0;
        
        // Recent products
        $recentProducts = $db->fetchAll("
            SELECT name, category, price, quantity 
            FROM products 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        
        echo $blade->make('dashboard.index', [
            'totalProducts' => $totalProducts,
            'lowStock' => $lowStock,
            'totalValue' => number_format($totalValue, 2),
            'recentProducts' => $recentProducts,
            'csrf_token' => $csrf_token
        ]);
        break;
        
    default:
        // If logged in, go to dashboard; otherwise go to home
        if (Session::isLoggedIn()) {
            header('Location: index.php?page=dashboard');
        } else {
            header('Location: index.php?page=home');
        }
        exit;

        
case 'users':
    // Require admin role
    Session::requireRole('admin');
    
    // Simple users listing
    $db = Database::getInstance();
    $users = $db->fetchAll("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC");
    
    echo $blade->make('users.index', [
        'users' => $users,
        'csrf_token' => $csrf_token
    ]);
    break;


case 'products':
    // Require authentication
    Session::requireAuth();
    
    // Load Product model
    $productModel = new \App\Models\Product();
    
    switch ($action) {
        case 'index':
            // View all products
            $page = $_GET['p'] ?? 1;
            $searchTerm = $_GET['search'] ?? '';
            
            if (!empty($searchTerm)) {
                $products = $productModel->search($searchTerm, $page);
                $totalProducts = count($productModel->search($searchTerm));
            } else {
                $products = $productModel->getAll($page);
                $totalProducts = $productModel->getTotalCount();
            }
            
            $categories = $productModel->getCategories();
            $locations = $productModel->getLocations();
            
            echo $blade->make('products.index', [
                'products' => $products,
                'totalProducts' => $totalProducts,
                'categories' => $categories,
                'locations' => $locations,
                'currentPage' => $page,
                'searchTerm' => $searchTerm,
                'csrf_token' => $csrf_token
            ]);
            break;
            
        case 'create':
            // Show create form
            $categories = $productModel->getCategories();
            $locations = $productModel->getLocations();
            
            echo $blade->make('products.create', [
                'categories' => $categories,
                'locations' => $locations,
                'csrf_token' => $csrf_token
            ]);
            break;
            
        case 'edit':
            // Show edit form
            $id = $_GET['id'] ?? 0;
            $product = $productModel->getById($id);
            
            if (!$product) {
                Session::flash('error', 'Product not found.');
                header('Location: index.php?page=products');
                exit;
            }
            
            $categories = $productModel->getCategories();
            $locations = $productModel->getLocations();
            
            echo $blade->make('products.edit', [
                'product' => $product,
                'categories' => $categories,
                'locations' => $locations,
                'csrf_token' => $csrf_token
            ]);
            break;
            
        default:
            header('Location: index.php?page=products');
            exit;

        // Add these inside the switch($action) for products:

case 'store':
    // Handle product creation
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // CSRF protection
        if (!hash_equals(Session::get('csrf_token', ''), $_POST['csrf_token'] ?? '')) {
            Session::flash('error', 'Security token invalid.');
            header('Location: index.php?page=products&action=create');
            exit;
        }
        
        // Validate required fields
        $required = ['name', 'sku', 'category', 'price', 'quantity', 'min_stock_level'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                Session::flash('error', "Please fill in all required fields.");
                header('Location: index.php?page=products&action=create');
                exit;
            }
        }
        
        // Process category (handle "other")
        $category = $_POST['category'];
        if ($category === 'other' && !empty($_POST['category_other'])) {
            $category = trim($_POST['category_other']);
        }
        
        // Process location (handle "other")
        $location = $_POST['location'] ?? '';
        if ($location === 'other' && !empty($_POST['location_other'])) {
            $location = trim($_POST['location_other']);
        }
        
        // Prepare product data
        $productData = [
            'name' => trim($_POST['name']),
            'description' => trim($_POST['description'] ?? ''),
            'category' => $category,
            'price' => floatval($_POST['price']),
            'quantity' => intval($_POST['quantity']),
            'sku' => trim($_POST['sku']),
            'supplier' => trim($_POST['supplier'] ?? ''),
            'location' => $location,
            'min_stock_level' => intval($_POST['min_stock_level']),
            'image_url' => null
        ];
        
        // Handle image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            $maxSize = 2 * 1024 * 1024; // 2MB
            
            if (in_array($_FILES['image']['type'], $allowedTypes) && 
                $_FILES['image']['size'] <= $maxSize) {
                
                // Create uploads directory if it doesn't exist
                $uploadDir = __DIR__ . '/uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                
                // Generate unique filename
                $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $filename = 'product_' . time() . '_' . uniqid() . '.' . $extension;
                $destination = $uploadDir . $filename;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                    $productData['image_url'] = $filename;
                }
            }
        }
        
        // Save to database
        try {
            $productModel = new \App\Models\Product();
            $productModel->create($productData);
            
            Session::flash('success', 'Product added successfully!');
            header('Location: index.php?page=products');
            exit;
            
        } catch (Exception $e) {
            Session::flash('error', 'Error saving product: ' . $e->getMessage());
            header('Location: index.php?page=products&action=create');
            exit;
        }
    }
    break;
    
case 'update':
    // Handle product update
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = $_GET['id'] ?? 0;
        
        // CSRF protection
        if (!hash_equals(Session::get('csrf_token', ''), $_POST['csrf_token'] ?? '')) {
            Session::flash('error', 'Security token invalid.');
            header('Location: index.php?page=products&action=edit&id=' . $id);
            exit;
        }
        
        // Validate required fields
        $required = ['name', 'sku', 'category', 'price', 'quantity', 'min_stock_level'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                Session::flash('error', "Please fill in all required fields.");
                header('Location: index.php?page=products&action=edit&id=' . $id);
                exit;
            }
        }
        
        // Process category (handle "other")
        $category = $_POST['category'];
        if ($category === 'other' && !empty($_POST['category_other'])) {
            $category = trim($_POST['category_other']);
        }
        
        // Process location (handle "other")
        $location = $_POST['location'] ?? '';
        if ($location === 'other' && !empty($_POST['location_other'])) {
            $location = trim($_POST['location_other']);
        }
        
        // Prepare product data
        $productData = [
            'name' => trim($_POST['name']),
            'description' => trim($_POST['description'] ?? ''),
            'category' => $category,
            'price' => floatval($_POST['price']),
            'quantity' => intval($_POST['quantity']),
            'sku' => trim($_POST['sku']),
            'supplier' => trim($_POST['supplier'] ?? ''),
            'location' => $location,
            'min_stock_level' => intval($_POST['min_stock_level']),
            'image_url' => $_POST['current_image'] ?? null
        ];
        
        // Handle image removal
        if (isset($_POST['remove_current_image']) && $_POST['remove_current_image'] == 'on') {
            if ($productData['image_url']) {
                $oldImage = __DIR__ . '/uploads/' . $productData['image_url'];
                if (file_exists($oldImage)) {
                    unlink($oldImage);
                }
                $productData['image_url'] = null;
            }
        }
        
        // Handle new image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            $maxSize = 2 * 1024 * 1024; // 2MB
            
            if (in_array($_FILES['image']['type'], $allowedTypes) && 
                $_FILES['image']['size'] <= $maxSize) {
                
                // Delete old image if exists
                if ($productData['image_url']) {
                    $oldImage = __DIR__ . '/uploads/' . $productData['image_url'];
                    if (file_exists($oldImage)) {
                        unlink($oldImage);
                    }
                }
                
                // Create uploads directory if it doesn't exist
                $uploadDir = __DIR__ . '/uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                
                // Generate unique filename
                $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $filename = 'product_' . time() . '_' . uniqid() . '.' . $extension;
                $destination = $uploadDir . $filename;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                    $productData['image_url'] = $filename;
                }
            }
        }
        
        // Update database
        try {
            $productModel = new \App\Models\Product();
            $productModel->update($id, $productData);
            
            Session::flash('success', 'Product updated successfully!');
            header('Location: index.php?page=products');
            exit;
            
        } catch (Exception $e) {
            Session::flash('error', 'Error updating product: ' . $e->getMessage());
            header('Location: index.php?page=products&action=edit&id=' . $id);
            exit;
        }
    }
    break;
    
case 'delete':
    // Handle product deletion
    $id = $_GET['id'] ?? 0;
    
    // CSRF protection
    if (!hash_equals(Session::get('csrf_token', ''), $_GET['csrf_token'] ?? '')) {
        Session::flash('error', 'Security token invalid.');
        header('Location: index.php?page=products');
        exit;
    }
    
    // Check if user is admin (only admins can delete)
    if (!Session::hasRole('admin')) {
        Session::flash('error', 'You do not have permission to delete products.');
        header('Location: index.php?page=products');
        exit;
    }
    
    try {
        $productModel = new \App\Models\Product();
        $product = $productModel->getById($id);
        
        if ($product) {
            // Delete associated image if exists
            if ($product['image_url']) {
                $imagePath = __DIR__ . '/uploads/' . $product['image_url'];
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
            }
            
            // Delete from database
            $productModel->delete($id);
            Session::flash('success', 'Product deleted successfully!');
        } else {
            Session::flash('error', 'Product not found.');
        }
        
    } catch (Exception $e) {
        Session::flash('error', 'Error deleting product: ' . $e->getMessage());
    }
    
    header('Location: index.php?page=products');
    exit;
    break;
    }
    break;
}