<?php
// Enable ALL error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start output buffering
ob_start();

// Login Processor - Handles login form submission
require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Session;
use App\Core\Auth;

// Start session
Session::start();

// Check if already logged in
if (Session::isLoggedIn()) {
    header('Location: index.php?page=dashboard');
    exit;
}

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF protection
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!hash_equals(Session::get('csrf_token', ''), $csrf_token)) {
        Session::flash('error', 'Security token invalid. Please try again.');
        header('Location: index.php?page=login');
        exit;
    }
    
    // Get form data
    $identifier = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    
    // Validate input
    if (empty($identifier) || empty($password)) {
        Session::flash('error', 'Please enter both username/email and password.');
        header('Location: index.php?page=login');
        exit;
    }
    
    // Attempt login
    $auth = new Auth();
    $user = $auth->login($identifier, $password);
    
    if ($user) {
        // Login successful
        Session::flash('success', 'Login successful! Welcome back, ' . htmlspecialchars($user['username']) . '.');
        
        // Set remember me cookie (optional)
        if ($remember) {
            setcookie('remember_user', $user['id'], time() + (86400 * 30), "/"); // 30 days
        }
        
        // Redirect to dashboard
        header('Location: index.php?page=dashboard');
        exit;
    } else {
        // Login failed - generic error (prevent user enumeration)
        Session::flash('error', 'Invalid credentials. Please try again.');
        header('Location: index.php?page=login');
        exit;
    }
} else {
    // Not a POST request - redirect to login page
    header('Location: index.php?page=login');
    exit;
}