<?php
// AJAX quantity update endpoint - SECURE VERSION
require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Database;
use App\Core\Session;

// Start session for authentication and CSRF
Session::start();

// Only allow AJAX requests
if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Direct access not allowed']));
}

// Check if user is logged in
if (!Session::isLoggedIn()) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Not authenticated']));
}

// CSRF Protection for AJAX
$csrf_token = $_POST['csrf_token'] ?? '';
if (!hash_equals(Session::get('csrf_token', ''), $csrf_token)) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'CSRF token invalid']));
}

// Check if user has permission to update quantities
// Only admin can update, users can only view
if (!Session::hasRole('admin')) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Permission denied. Only admins can update quantities.']));
}

// Get POST data
$productId = $_POST['product_id'] ?? 0;
$newQuantity = $_POST['quantity'] ?? 0;
$action = $_POST['action'] ?? '';

// Validate input
if ($productId <= 0) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Invalid product ID']));
}

if ($newQuantity < 0) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Quantity cannot be negative']));
}

// Get current quantity
$db = Database::getInstance();

try {
    // Get current product info
    $product = $db->fetchOne("SELECT quantity, min_stock_level FROM products WHERE id = ?", [$productId]);
    
    if (!$product) {
        http_response_code(404);
        die(json_encode(['success' => false, 'error' => 'Product not found']));
    }
    
    $currentQuantity = $product['quantity'];
    $minStockLevel = $product['min_stock_level'];
    
    // Update quantity in database
    $sql = "UPDATE products SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
    $db->executeQuery($sql, [$newQuantity, $productId]);
    
    // Get updated product info
    $updatedProduct = $db->fetchOne("SELECT quantity, min_stock_level, name FROM products WHERE id = ?", [$productId]);
    
    // Determine stock status
    $stockStatus = 'in_stock';
    if ($updatedProduct['quantity'] == 0) {
        $stockStatus = 'out_of_stock';
    } elseif ($updatedProduct['quantity'] < $updatedProduct['min_stock_level']) {
        $stockStatus = 'low_stock';
    }
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Quantity updated successfully',
        'product' => [
            'id' => $productId,
            'quantity' => $updatedProduct['quantity'],
            'min_stock_level' => $updatedProduct['min_stock_level'],
            'name' => $updatedProduct['name'],
            'stock_status' => $stockStatus,
            'stock_class' => $stockStatus === 'out_of_stock' ? 'stock-low' : 
                           ($stockStatus === 'low_stock' ? 'stock-warning' : 'stock-ok')
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    error_log("Quantity update error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}